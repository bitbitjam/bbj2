#ifndef _UCL_H
#define _UCL_H
extern void __LIB__ __CALLEE__ ucl_uncompress(uchar *src, uchar *dst);
#endif

