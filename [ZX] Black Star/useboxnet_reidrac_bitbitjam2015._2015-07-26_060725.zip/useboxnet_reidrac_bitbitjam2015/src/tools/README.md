These are open source / public domain tools required to build the game.

Required:

 - gcc (other may work too)
 - GNU make
 - UCL library (1.03 recommended, other may work too)
 - python 2.7

