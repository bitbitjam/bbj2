#ifndef _NTROPIC_H
#define _NTROPIC_H

// loop 0 for no loop, anything else will loop
extern void __LIB__ __CALLEE__ ntropic_play(uchar *song_addr, uchar loop);

#endif
